create table colors(
    id INTEGER PRIMARY KEY,
    name varchar(50) NOT NULL
)