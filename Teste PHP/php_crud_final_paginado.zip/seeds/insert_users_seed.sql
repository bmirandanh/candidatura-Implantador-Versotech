INSERT INTO users(name, email)
    VALUES
        ('Foo Bar', 'foo@bar'),
        ('Bar Baz', 'bar@baz'),
        ('Baz Foo', 'baz@foo')