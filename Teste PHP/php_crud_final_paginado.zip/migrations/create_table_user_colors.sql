create table user_colors(
    user_id INTEGER NOT NULL,
    color_id INTEGER NOT NULL
)